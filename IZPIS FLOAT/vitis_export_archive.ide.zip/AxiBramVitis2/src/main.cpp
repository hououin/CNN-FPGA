#include <stdio.h>
#include <xcrazyfunction.h>
#include <math.h>
#include <xparameters.h>

//Point to the BRAM Controllers
float *XVecHW = (float *) 0x40010000;
float *resHW = (float *) 0x40012000;

//Crazy function IP core
XCrazyfunction doCrazyFunction;
XCrazyfunction_Config *doCrazyFunction_cfg;

void init_crazyCore()
{
	int status = 0;
	doCrazyFunction_cfg = XCrazyfunction_LookupConfig(XPAR_CRAZYFUNCTION_0_DEVICE_ID);
	if (doCrazyFunction_cfg)
	{
		status = XCrazyfunction_CfgInitialize(&doCrazyFunction, doCrazyFunction_cfg);
		if(status != XST_SUCCESS)
		{
			printf("Failed to initialize\n");
		}
	}
}


int main()
{
	init_crazyCore();
	printf("Test BRAM\n");

	float i = 0.0f;

	for(int idxX = 0; idxX < 100; idxX++)
	{
		XVecHW[idxX] = i;

		printf("%f\n", XVecHW[idxX]);

		i = i + 1.0f;
	}


	XCrazyfunction_Start(&doCrazyFunction);
	while(!XCrazyfunction_IsDone(&doCrazyFunction));
	printf("HW test finished test 10\n");

	for(int j = 0; j < 100; j++)
	{
		printf("%f %x %f %x\n",  XVecHW[j], XVecHW[j], resHW[j], resHW[j]);
	}

	printf("-----------\n");

	return 0;
}
